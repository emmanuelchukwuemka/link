module.exports=[30785,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_activate-card_page_actions_0d0j5qu.js.map