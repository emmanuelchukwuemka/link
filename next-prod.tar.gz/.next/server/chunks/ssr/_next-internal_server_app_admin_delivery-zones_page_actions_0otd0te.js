module.exports=[58243,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_delivery-zones_page_actions_0otd0te.js.map