module.exports=[21098,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_cards_generate_page_actions_0x2uyoi.js.map