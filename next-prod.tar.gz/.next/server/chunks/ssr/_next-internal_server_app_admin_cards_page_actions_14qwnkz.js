module.exports=[76158,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_cards_page_actions_14qwnkz.js.map