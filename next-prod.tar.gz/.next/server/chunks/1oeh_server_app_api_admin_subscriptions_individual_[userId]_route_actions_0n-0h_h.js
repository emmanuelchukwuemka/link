module.exports=[62697,(e,o,d)=>{}];

//# sourceMappingURL=1oeh_server_app_api_admin_subscriptions_individual_%5BuserId%5D_route_actions_0n-0h_h.js.map