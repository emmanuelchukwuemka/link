var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/q/[username]/route.js")
R.c("server/chunks/[root-of-the-server]__0ni2br6._.js")
R.c("server/chunks/_1ha-c_8._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_q_[username]_route_actions_1m1y33w.js")
R.m(90925)
module.exports=R.m(90925).exports
