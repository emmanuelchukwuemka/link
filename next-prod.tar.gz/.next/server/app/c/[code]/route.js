var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/c/[code]/route.js")
R.c("server/chunks/[root-of-the-server]__07z-fjh._.js")
R.c("server/chunks/_1ha-c_8._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_c_[code]_route_actions_03-_yqq.js")
R.m(2271)
module.exports=R.m(2271).exports
