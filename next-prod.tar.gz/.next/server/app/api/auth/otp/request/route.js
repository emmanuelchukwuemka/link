var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/otp/request/route.js")
R.c("server/chunks/[root-of-the-server]__1d8-9l-._.js")
R.c("server/chunks/[root-of-the-server]__0qb0cy7._.js")
R.c("server/chunks/_1ha-c_8._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_otp_request_route_actions_1bocav0.js")
R.m(4400)
module.exports=R.m(4400).exports
