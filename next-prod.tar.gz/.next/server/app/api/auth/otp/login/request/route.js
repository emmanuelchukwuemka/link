var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/otp/login/request/route.js")
R.c("server/chunks/[root-of-the-server]__0wt6iy_._.js")
R.c("server/chunks/[root-of-the-server]__0qb0cy7._.js")
R.c("server/chunks/_1ha-c_8._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_otp_login_request_route_actions_0gd-5lw.js")
R.m(249)
module.exports=R.m(249).exports
