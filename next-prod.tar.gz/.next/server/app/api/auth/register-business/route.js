var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/register-business/route.js")
R.c("server/chunks/[root-of-the-server]__1_v8k5i._.js")
R.c("server/chunks/node_modules_next_1_14bcs._.js")
R.c("server/chunks/_041rzm3._.js")
R.c("server/chunks/_1ha-c_8._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_register-business_route_actions_18hc86_.js")
R.m(78406)
module.exports=R.m(78406).exports
