var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/logout/route.js")
R.c("server/chunks/[root-of-the-server]__02hs15x._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/node_modules_next_1_14bcs._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_logout_route_actions_0regwyr.js")
R.m(83932)
module.exports=R.m(83932).exports
