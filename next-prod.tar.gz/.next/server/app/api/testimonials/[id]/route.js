var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/testimonials/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__14vlkrc._.js")
R.c("server/chunks/node_modules_next_1_14bcs._.js")
R.c("server/chunks/_041rzm3._.js")
R.c("server/chunks/_1ha-c_8._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_testimonials_[id]_route_actions_1dis-28.js")
R.m(19829)
module.exports=R.m(19829).exports
