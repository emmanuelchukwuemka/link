var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/testimonials/route.js")
R.c("server/chunks/[root-of-the-server]__0o0elog._.js")
R.c("server/chunks/node_modules_next_1_14bcs._.js")
R.c("server/chunks/_041rzm3._.js")
R.c("server/chunks/_1ha-c_8._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_testimonials_route_actions_0e8eko-.js")
R.m(84438)
module.exports=R.m(84438).exports
