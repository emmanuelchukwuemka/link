var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/store-categories/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__1kwygc7._.js")
R.c("server/chunks/node_modules_next_1_14bcs._.js")
R.c("server/chunks/_041rzm3._.js")
R.c("server/chunks/_1ha-c_8._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_store-categories_[id]_route_actions_177gn39.js")
R.m(21751)
module.exports=R.m(21751).exports
