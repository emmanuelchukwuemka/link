var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/store-categories/route.js")
R.c("server/chunks/[root-of-the-server]__1aiu4q1._.js")
R.c("server/chunks/node_modules_next_1_14bcs._.js")
R.c("server/chunks/_041rzm3._.js")
R.c("server/chunks/_1ha-c_8._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_store-categories_route_actions_1ypst6b.js")
R.m(67642)
module.exports=R.m(67642).exports
