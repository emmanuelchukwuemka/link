var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/debug-otp/route.js")
R.c("server/chunks/[root-of-the-server]__1n4bcy_._.js")
R.c("server/chunks/_1ha-c_8._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_debug-otp_route_actions_1k_gvhz.js")
R.m(97916)
module.exports=R.m(97916).exports
