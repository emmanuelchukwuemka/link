var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/cards/bulk/route.js")
R.c("server/chunks/[root-of-the-server]__0ti_l_q._.js")
R.c("server/chunks/node_modules_next_1_14bcs._.js")
R.c("server/chunks/_041rzm3._.js")
R.c("server/chunks/_1ha-c_8._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_cards_bulk_route_actions_0az5_50.js")
R.m(97670)
module.exports=R.m(97670).exports
