var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/cards/import-one/route.js")
R.c("server/chunks/[root-of-the-server]__17hlj1m._.js")
R.c("server/chunks/node_modules_next_1_14bcs._.js")
R.c("server/chunks/_1ha-c_8._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_041rzm3._.js")
R.c("server/chunks/_next-internal_server_app_api_cards_import-one_route_actions_1jm76qs.js")
R.m(25152)
module.exports=R.m(25152).exports
