var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/cards/[code]/route.js")
R.c("server/chunks/[root-of-the-server]__139ovge._.js")
R.c("server/chunks/node_modules_next_1_14bcs._.js")
R.c("server/chunks/_1ha-c_8._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_041rzm3._.js")
R.c("server/chunks/_next-internal_server_app_api_cards_[code]_route_actions_1plejs1.js")
R.m(69954)
module.exports=R.m(69954).exports
