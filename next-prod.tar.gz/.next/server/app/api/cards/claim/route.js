var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/cards/claim/route.js")
R.c("server/chunks/[root-of-the-server]__0nr6dx7._.js")
R.c("server/chunks/node_modules_next_1_14bcs._.js")
R.c("server/chunks/_041rzm3._.js")
R.c("server/chunks/_1ha-c_8._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_cards_claim_route_actions_20hra03.js")
R.m(27685)
module.exports=R.m(27685).exports
