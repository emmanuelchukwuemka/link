var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/cards/mine/route.js")
R.c("server/chunks/[root-of-the-server]__0tj2o62._.js")
R.c("server/chunks/node_modules_next_1_14bcs._.js")
R.c("server/chunks/_041rzm3._.js")
R.c("server/chunks/_1ha-c_8._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_cards_mine_route_actions_0t1hhvw.js")
R.m(57019)
module.exports=R.m(57019).exports
