var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/business/subscriptions/verify/route.js")
R.c("server/chunks/[root-of-the-server]__1h8-518._.js")
R.c("server/chunks/[root-of-the-server]__0qb0cy7._.js")
R.c("server/chunks/_1ha-c_8._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/1oeh_server_app_api_business_subscriptions_verify_route_actions_09xon_p.js")
R.m(55623)
module.exports=R.m(55623).exports
