var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/business/cards/route.js")
R.c("server/chunks/[root-of-the-server]__0wv_1l-._.js")
R.c("server/chunks/node_modules_next_1_14bcs._.js")
R.c("server/chunks/_041rzm3._.js")
R.c("server/chunks/_1ha-c_8._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_business_cards_route_actions_0-_4rdf.js")
R.m(84134)
module.exports=R.m(84134).exports
