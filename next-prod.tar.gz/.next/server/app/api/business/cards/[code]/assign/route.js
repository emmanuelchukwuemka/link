var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/business/cards/[code]/assign/route.js")
R.c("server/chunks/[root-of-the-server]__1bl7-8o._.js")
R.c("server/chunks/node_modules_next_1_14bcs._.js")
R.c("server/chunks/_041rzm3._.js")
R.c("server/chunks/_1ha-c_8._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_business_cards_[code]_assign_route_actions_0y7of73.js")
R.m(72982)
module.exports=R.m(72982).exports
