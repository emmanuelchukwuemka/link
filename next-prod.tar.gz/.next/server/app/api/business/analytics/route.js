var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/business/analytics/route.js")
R.c("server/chunks/[root-of-the-server]__20m4xux._.js")
R.c("server/chunks/node_modules_next_1_14bcs._.js")
R.c("server/chunks/_041rzm3._.js")
R.c("server/chunks/_1ha-c_8._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_business_analytics_route_actions_0g6mbc7.js")
R.m(52782)
module.exports=R.m(52782).exports
