var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/business/employees/route.js")
R.c("server/chunks/[root-of-the-server]__103bbtz._.js")
R.c("server/chunks/node_modules_next_1_14bcs._.js")
R.c("server/chunks/_1ha-c_8._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_041rzm3._.js")
R.c("server/chunks/_next-internal_server_app_api_business_employees_route_actions_0_p1x6t.js")
R.m(41627)
module.exports=R.m(41627).exports
