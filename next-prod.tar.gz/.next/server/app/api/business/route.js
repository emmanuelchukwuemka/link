var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/business/route.js")
R.c("server/chunks/[root-of-the-server]__06169gz._.js")
R.c("server/chunks/node_modules_next_1_14bcs._.js")
R.c("server/chunks/_041rzm3._.js")
R.c("server/chunks/_1ha-c_8._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_business_route_actions_0c4fma-.js")
R.m(95546)
module.exports=R.m(95546).exports
