var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/notifications/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__01kxil-._.js")
R.c("server/chunks/node_modules_next_1_14bcs._.js")
R.c("server/chunks/_041rzm3._.js")
R.c("server/chunks/_1ha-c_8._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_notifications_[id]_route_actions_0ao6--l.js")
R.m(40190)
module.exports=R.m(40190).exports
