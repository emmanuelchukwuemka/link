var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/profile/username/route.js")
R.c("server/chunks/[root-of-the-server]__0i4c72-._.js")
R.c("server/chunks/node_modules_next_1_14bcs._.js")
R.c("server/chunks/_041rzm3._.js")
R.c("server/chunks/_1ha-c_8._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_profile_username_route_actions_15i0np2.js")
R.m(70707)
module.exports=R.m(70707).exports
