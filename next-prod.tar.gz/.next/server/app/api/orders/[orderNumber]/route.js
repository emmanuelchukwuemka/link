var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/orders/[orderNumber]/route.js")
R.c("server/chunks/[root-of-the-server]__16logou._.js")
R.c("server/chunks/_1ha-c_8._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_orders_[orderNumber]_route_actions_0phw859.js")
R.m(64475)
module.exports=R.m(64475).exports
