var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/orders/[orderNumber]/complete-profile/route.js")
R.c("server/chunks/[root-of-the-server]__0_f-16v._.js")
R.c("server/chunks/node_modules_next_1_14bcs._.js")
R.c("server/chunks/_041rzm3._.js")
R.c("server/chunks/_1ha-c_8._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/1oeh_server_app_api_orders_[orderNumber]_complete-profile_route_actions_0a9n31e.js")
R.m(76927)
module.exports=R.m(76927).exports
