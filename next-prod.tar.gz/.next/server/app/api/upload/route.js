var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/upload/route.js")
R.c("server/chunks/[root-of-the-server]__0c3q8ex._.js")
R.c("server/chunks/node_modules_next_1_14bcs._.js")
R.c("server/chunks/_1ha-c_8._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_041rzm3._.js")
R.c("server/chunks/_next-internal_server_app_api_upload_route_actions_1yybo5l.js")
R.m(55739)
module.exports=R.m(55739).exports
