var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/leads/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__1p3thes._.js")
R.c("server/chunks/node_modules_next_1_14bcs._.js")
R.c("server/chunks/_041rzm3._.js")
R.c("server/chunks/_1ha-c_8._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_leads_[id]_route_actions_1e5wt7p.js")
R.m(16867)
module.exports=R.m(16867).exports
