var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/support/messages/read/route.js")
R.c("server/chunks/[root-of-the-server]__200sr-o._.js")
R.c("server/chunks/node_modules_next_1_14bcs._.js")
R.c("server/chunks/_041rzm3._.js")
R.c("server/chunks/_1ha-c_8._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_support_messages_read_route_actions_1onjc18.js")
R.m(56766)
module.exports=R.m(56766).exports
