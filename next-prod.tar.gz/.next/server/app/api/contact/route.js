var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/contact/route.js")
R.c("server/chunks/[root-of-the-server]__18d97a2._.js")
R.c("server/chunks/[root-of-the-server]__0qb0cy7._.js")
R.c("server/chunks/_1ha-c_8._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_contact_route_actions_03lj3y1.js")
R.m(86590)
module.exports=R.m(86590).exports
