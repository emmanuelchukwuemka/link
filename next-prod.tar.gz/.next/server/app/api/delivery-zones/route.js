var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/delivery-zones/route.js")
R.c("server/chunks/[root-of-the-server]__1t9qnxm._.js")
R.c("server/chunks/_1ha-c_8._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_delivery-zones_route_actions_0iztiha.js")
R.m(68156)
module.exports=R.m(68156).exports
