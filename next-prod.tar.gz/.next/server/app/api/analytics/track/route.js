var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/analytics/track/route.js")
R.c("server/chunks/[root-of-the-server]__029dqn_._.js")
R.c("server/chunks/_1ha-c_8._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_analytics_track_route_actions_0w-i3l6.js")
R.m(95170)
module.exports=R.m(95170).exports
