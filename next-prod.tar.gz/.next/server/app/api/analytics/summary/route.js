var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/analytics/summary/route.js")
R.c("server/chunks/[root-of-the-server]__03brud4._.js")
R.c("server/chunks/node_modules_next_1_14bcs._.js")
R.c("server/chunks/_041rzm3._.js")
R.c("server/chunks/_1ha-c_8._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_analytics_summary_route_actions_0crb2sz.js")
R.m(91033)
module.exports=R.m(91033).exports
