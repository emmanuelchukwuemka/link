var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/payments/simulate/route.js")
R.c("server/chunks/[root-of-the-server]__1mj88_a._.js")
R.c("server/chunks/[root-of-the-server]__0qb0cy7._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_1ha-c_8._.js")
R.c("server/chunks/_next-internal_server_app_api_payments_simulate_route_actions_0vj8wgj.js")
R.m(73371)
module.exports=R.m(73371).exports
