var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/services/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__12qd8kw._.js")
R.c("server/chunks/node_modules_next_1_14bcs._.js")
R.c("server/chunks/_041rzm3._.js")
R.c("server/chunks/_1ha-c_8._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_services_[id]_route_actions_0127l3r.js")
R.m(62818)
module.exports=R.m(62818).exports
