var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/services/route.js")
R.c("server/chunks/[root-of-the-server]__0fgp9p3._.js")
R.c("server/chunks/node_modules_next_1_14bcs._.js")
R.c("server/chunks/_1ha-c_8._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_041rzm3._.js")
R.c("server/chunks/_next-internal_server_app_api_services_route_actions_045zq8g.js")
R.m(77746)
module.exports=R.m(77746).exports
