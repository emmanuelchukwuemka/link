var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/links/[id]/click/route.js")
R.c("server/chunks/[root-of-the-server]__02nnf8f._.js")
R.c("server/chunks/_1ha-c_8._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_links_[id]_click_route_actions_1fnhp5x.js")
R.m(49373)
module.exports=R.m(49373).exports
