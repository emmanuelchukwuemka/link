var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/links/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__1eczwt4._.js")
R.c("server/chunks/node_modules_next_1_14bcs._.js")
R.c("server/chunks/_041rzm3._.js")
R.c("server/chunks/_1ha-c_8._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_links_[id]_route_actions_13q0ro3.js")
R.m(73250)
module.exports=R.m(73250).exports
