var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/bootstrap/route.js")
R.c("server/chunks/[root-of-the-server]__0-77r0t._.js")
R.c("server/chunks/node_modules_next_1_14bcs._.js")
R.c("server/chunks/_041rzm3._.js")
R.c("server/chunks/_1ha-c_8._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_bootstrap_route_actions_04cn4x4.js")
R.m(17570)
module.exports=R.m(17570).exports
