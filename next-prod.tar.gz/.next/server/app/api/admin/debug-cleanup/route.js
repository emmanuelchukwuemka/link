var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/debug-cleanup/route.js")
R.c("server/chunks/[root-of-the-server]__0doeqm4._.js")
R.c("server/chunks/_1ha-c_8._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_debug-cleanup_route_actions_0whps-m.js")
R.m(21738)
module.exports=R.m(21738).exports
