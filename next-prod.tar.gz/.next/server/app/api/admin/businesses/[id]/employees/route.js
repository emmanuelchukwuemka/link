var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/businesses/[id]/employees/route.js")
R.c("server/chunks/[root-of-the-server]__0jma581._.js")
R.c("server/chunks/node_modules_next_1_14bcs._.js")
R.c("server/chunks/_041rzm3._.js")
R.c("server/chunks/_1ha-c_8._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/1oeh_server_app_api_admin_businesses_[id]_employees_route_actions_0rcc1_5.js")
R.m(92929)
module.exports=R.m(92929).exports
