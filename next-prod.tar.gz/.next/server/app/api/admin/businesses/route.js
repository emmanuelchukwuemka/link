var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/businesses/route.js")
R.c("server/chunks/[root-of-the-server]__0iz5b5-._.js")
R.c("server/chunks/node_modules_next_1_14bcs._.js")
R.c("server/chunks/_041rzm3._.js")
R.c("server/chunks/_1ha-c_8._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_businesses_route_actions_04kv74u.js")
R.m(76288)
module.exports=R.m(76288).exports
