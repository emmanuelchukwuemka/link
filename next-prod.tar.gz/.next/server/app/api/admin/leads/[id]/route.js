var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/leads/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0sz9-y9._.js")
R.c("server/chunks/node_modules_next_1_14bcs._.js")
R.c("server/chunks/_041rzm3._.js")
R.c("server/chunks/_1ha-c_8._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_leads_[id]_route_actions_1e0d8-1.js")
R.m(54307)
module.exports=R.m(54307).exports
