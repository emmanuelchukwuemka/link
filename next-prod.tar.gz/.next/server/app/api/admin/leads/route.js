var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/leads/route.js")
R.c("server/chunks/[root-of-the-server]__0x7nu0_._.js")
R.c("server/chunks/node_modules_next_1_14bcs._.js")
R.c("server/chunks/_041rzm3._.js")
R.c("server/chunks/_1ha-c_8._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_leads_route_actions_1929pwt.js")
R.m(88666)
module.exports=R.m(88666).exports
