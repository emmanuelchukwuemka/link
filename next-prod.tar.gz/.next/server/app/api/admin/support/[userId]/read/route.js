var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/support/[userId]/read/route.js")
R.c("server/chunks/[root-of-the-server]__1pdod3q._.js")
R.c("server/chunks/node_modules_next_1_14bcs._.js")
R.c("server/chunks/_041rzm3._.js")
R.c("server/chunks/_1ha-c_8._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_support_[userId]_read_route_actions_0svk5la.js")
R.m(36353)
module.exports=R.m(36353).exports
