var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/support/route.js")
R.c("server/chunks/[root-of-the-server]__0f1yb2d._.js")
R.c("server/chunks/node_modules_next_1_14bcs._.js")
R.c("server/chunks/_041rzm3._.js")
R.c("server/chunks/_1ha-c_8._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_support_route_actions_058t7e7.js")
R.m(81426)
module.exports=R.m(81426).exports
