var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/subscriptions/business/[businessId]/route.js")
R.c("server/chunks/[root-of-the-server]__1ki55uz._.js")
R.c("server/chunks/node_modules_next_1_14bcs._.js")
R.c("server/chunks/_1ha-c_8._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_041rzm3._.js")
R.c("server/chunks/1oeh_server_app_api_admin_subscriptions_business_[businessId]_route_actions_1cyh2pm.js")
R.m(99064)
module.exports=R.m(99064).exports
