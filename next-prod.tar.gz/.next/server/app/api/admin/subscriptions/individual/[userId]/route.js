var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/subscriptions/individual/[userId]/route.js")
R.c("server/chunks/[root-of-the-server]__065t91p._.js")
R.c("server/chunks/node_modules_next_1_14bcs._.js")
R.c("server/chunks/_041rzm3._.js")
R.c("server/chunks/_1ha-c_8._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/1oeh_server_app_api_admin_subscriptions_individual_[userId]_route_actions_0n-0h_h.js")
R.m(29339)
module.exports=R.m(29339).exports
