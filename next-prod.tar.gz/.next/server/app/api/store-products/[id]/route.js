var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/store-products/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__1exgtp3._.js")
R.c("server/chunks/node_modules_next_1_14bcs._.js")
R.c("server/chunks/_041rzm3._.js")
R.c("server/chunks/_1ha-c_8._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_store-products_[id]_route_actions_0xq6lo2.js")
R.m(42480)
module.exports=R.m(42480).exports
