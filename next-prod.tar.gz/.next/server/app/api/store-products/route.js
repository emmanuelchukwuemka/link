var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/store-products/route.js")
R.c("server/chunks/[root-of-the-server]__1zlcihr._.js")
R.c("server/chunks/node_modules_next_1_14bcs._.js")
R.c("server/chunks/_041rzm3._.js")
R.c("server/chunks/_1ha-c_8._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_store-products_route_actions_11xspgy.js")
R.m(7011)
module.exports=R.m(7011).exports
